"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useToast } from "@/hooks/use-toast"
import {
  Search,
  Plus,
  Eye,
  FileText,
  Users,
  Clock,
  BookOpen,
  Send,
  Edit,
  Trophy,
  TrendingUp,
  Award,
  Target,
  Download,
  Filter,
  BarChart3,
  GraduationCap,
  Star,
  AlertCircle,
  RefreshCw,
  ExternalLink,
} from "lucide-react"
import { getDivisionColor } from "@/lib/division"

interface DivisionResult {
  division: "DIVISION_1" | "DIVISION_2" | "DIVISION_3" | "DIVISION_4" | "UNGRADED" | "FAIL"
  aggregate: number
  label: string
  color: string
  subjects: {
    subjectId: string
    subjectName: string
    grade: string
    gradeValue: number
  }[]
}

interface Student {
  id: string
  name: string
  photo?: string
  gender: string
  class: {
    id: string
    name: string
  }
  parent?: {
    name: string
    email: string
  }
  reportCards: ReportCard[]
  divisions: {
    BOT: DivisionResult | null
    MID: DivisionResult | null
    END: DivisionResult | null
  }
}

interface ReportCard {
  id: string
  discipline: string
  cleanliness: string
  classWorkPresentation: string
  adherenceToSchool: string
  coCurricularActivities: string
  considerationToOthers: string
  speakingEnglish: string
  classTeacherComment?: string
  headteacherComment?: string
  isApproved: boolean
  approvedAt?: string
  createdAt: string
  updatedAt: string
}

interface Class {
  id: string
  name: string
}

interface Term {
  id: string
  name: string
}

interface AcademicYear {
  id: string
  name: string
  isCurrent: boolean
}

interface GradingSystem {
  id: string
  name: string
  grades: any[]
  isActive: boolean
}

interface DivisionStatistics {
  totalStudents: number
  divisions: Record<string, number>
  passRate: number
}

export default function TeacherReportsPage() {
  const [students, setStudents] = useState<Student[]>([])
  const [classes, setClasses] = useState<Class[]>([])
  const [terms, setTerms] = useState<Term[]>([])
  const [academicYears, setAcademicYears] = useState<AcademicYear[]>([])
  const [gradingSystem, setGradingSystem] = useState<GradingSystem | null>(null)
  const [statistics, setStatistics] = useState<Record<string, DivisionStatistics>>({})
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedClass, setSelectedClass] = useState<string>("")
  const [selectedTerm, setSelectedTerm] = useState<string>("")
  const [selectedAcademicYear, setSelectedAcademicYear] = useState<string>("")
  const [selectedExamType, setSelectedExamType] = useState<"BOT" | "MID" | "END">("BOT")
  const [divisionFilter, setDivisionFilter] = useState<string>("all")
  const [reportStatusFilter, setReportStatusFilter] = useState<string>("all")
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isAnalyticsDialogOpen, setIsAnalyticsDialogOpen] = useState(false)
  const [createMode, setCreateMode] = useState<"individual" | "bulk">("individual")
  const [bulkReports, setBulkReports] = useState<any[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isExporting, setIsExporting] = useState(false)
  const { toast } = useToast()

  const [reportForm, setReportForm] = useState({
    studentId: "",
    discipline: "",
    cleanliness: "",
    classWorkPresentation: "",
    adherenceToSchool: "",
    coCurricularActivities: "",
    considerationToOthers: "",
    speakingEnglish: "",
    classTeacherComment: "",
  })

  useEffect(() => {
    fetchInitialData()
  }, [])

  useEffect(() => {
    if (selectedClass && selectedTerm && selectedAcademicYear) {
      fetchStudentsWithDivisions()
    }
  }, [selectedClass, selectedTerm, selectedAcademicYear])

  const fetchInitialData = async () => {
    try {
      await Promise.all([fetchTeacherClasses(), fetchTerms(), fetchAcademicYears(), fetchGradingSystem()])
    } catch (error) {
      console.error("Error fetching initial data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const fetchGradingSystem = async () => {
    try {
      const response = await fetch("/api/grading-system")
      if (response.ok) {
        const data = await response.json()
        const activeSystem = data.gradingSystems?.find((system: GradingSystem) => system.isActive)
        setGradingSystem(activeSystem || data.gradingSystems?.[0] || null)
      }
    } catch (error) {
      console.error("Error fetching grading system:", error)
    }
  }

  const fetchTeacherClasses = async () => {
    try {
      const response = await fetch("/api/teacher/classes")
      if (response.ok) {
        const data = await response.json()
        setClasses(data.classes || [])
        if (data.classes && data.classes.length > 0) {
          setSelectedClass(data.classes[0].id)
        }
      }
    } catch (error) {
      console.error("Error fetching teacher classes:", error)
      setClasses([])
    }
  }

  const fetchTerms = async () => {
    try {
      const response = await fetch("/api/terms")
      if (response.ok) {
        const data = await response.json()
        setTerms(data.terms || [])
        if (data.terms && data.terms.length > 0) {
          setSelectedTerm(data.terms[0].id)
        }
      }
    } catch (error) {
      console.error("Error fetching terms:", error)
      setTerms([])
    }
  }

  const fetchAcademicYears = async () => {
    try {
      const response = await fetch("/api/academic-years")
      if (response.ok) {
        const data = await response.json()
        setAcademicYears(data.academicYears || [])
        const currentYear = data.academicYears?.find((year: AcademicYear) => year.isCurrent)
        if (currentYear) {
          setSelectedAcademicYear(currentYear.id)
        }
      }
    } catch (error) {
      console.error("Error fetching academic years:", error)
      setAcademicYears([])
    }
  }

  const fetchStudentsWithDivisions = async () => {
    try {
      setIsRefreshing(true)
      const params = new URLSearchParams()
      if (selectedClass) params.append("classId", selectedClass)
      if (selectedTerm) params.append("termId", selectedTerm)
      if (selectedAcademicYear) params.append("academicYearId", selectedAcademicYear)

      const response = await fetch(`/api/students/divisions?${params}`)
      if (response.ok) {
        const data = await response.json()
        setStudents(data.students || [])
        setStatistics(data.statistics || {})
      }
    } catch (error) {
      console.error("Error fetching students with divisions:", error)
      toast({
        title: "Error",
        description: "Failed to fetch student data",
        variant: "destructive",
      })
    } finally {
      setIsRefreshing(false)
    }
  }

  const handleCreateReport = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const response = await fetch("/api/report-cards/upsert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...reportForm,
          termId: selectedTerm,
          academicYearId: selectedAcademicYear,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: "Success",
          description: data.isUpdate ? "Report card updated successfully" : "Report card created successfully",
        })
        setIsCreateDialogOpen(false)
        resetReportForm()
        fetchStudentsWithDivisions()
      } else {
        throw new Error("Failed to save report card")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save report card",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleBulkCreateReports = async () => {
    setIsSubmitting(true)

    try {
      const response = await fetch("/api/report-cards/bulk-upsert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reportCards: bulkReports,
          termId: selectedTerm,
          academicYearId: selectedAcademicYear,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: "Success",
          description: `${data.successful} report cards processed successfully. ${data.failed} failed.`,
        })
        setIsCreateDialogOpen(false)
        resetReportForm()
        fetchStudentsWithDivisions()
      } else {
        throw new Error("Failed to process bulk report cards")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process bulk report cards",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleExportData = async () => {
    setIsExporting(true)
    try {
      const params = new URLSearchParams()
      if (selectedClass) params.append("classId", selectedClass)
      if (selectedTerm) params.append("termId", selectedTerm)
      if (selectedAcademicYear) params.append("academicYearId", selectedAcademicYear)

      const response = await fetch(`/api/teacher/classes/${selectedClass}/export?${params}`)
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `class-performance-${selectedClass}-${selectedTerm}.xlsx`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
        toast({
          title: "Success",
          description: "Performance data exported successfully",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export data",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  const resetReportForm = () => {
    setReportForm({
      studentId: "",
      discipline: "",
      cleanliness: "",
      classWorkPresentation: "",
      adherenceToSchool: "",
      coCurricularActivities: "",
      considerationToOthers: "",
      speakingEnglish: "",
      classTeacherComment: "",
    })
  }

  const getGradeOptions = () => {
    if (!gradingSystem || !gradingSystem.grades) {
      return [
        { value: "A", label: "A - Excellent" },
        { value: "B", label: "B - Very Good" },
        { value: "C", label: "C - Good" },
        { value: "D", label: "D - Fair" },
        { value: "E", label: "E - Needs Improvement" },
      ]
    }

    const grades = typeof gradingSystem.grades === "string" ? JSON.parse(gradingSystem.grades) : gradingSystem.grades
    return grades.map((grade: any) => ({
      value: grade.grade,
      label: `${grade.grade} - ${grade.description || grade.comment || grade.grade}`,
    }))
  }

  const handleOpenCreateDialog = (mode: "individual" | "bulk") => {
    setCreateMode(mode)
    if (mode === "bulk") {
      // Initialize bulk reports with existing data
      const initialReports = students.map((student) => {
        const existingReport = student.reportCards?.[0]
        return {
          studentId: student.id,
          discipline: existingReport?.discipline || "",
          cleanliness: existingReport?.cleanliness || "",
          classWorkPresentation: existingReport?.classWorkPresentation || "",
          adherenceToSchool: existingReport?.adherenceToSchool || "",
          coCurricularActivities: existingReport?.coCurricularActivities || "",
          considerationToOthers: existingReport?.considerationToOthers || "",
          speakingEnglish: existingReport?.speakingEnglish || "",
          classTeacherComment: existingReport?.classTeacherComment || "",
          hasExistingReport: !!existingReport,
          reportId: existingReport?.id,
        }
      })
      setBulkReports(initialReports)
    }
    setIsCreateDialogOpen(true)
  }

  const handleStudentSelect = (studentId: string) => {
    const student = students.find((s) => s.id === studentId)
    setSelectedStudent(student || null)

    // Pre-fill form with existing report data if available
    const existingReport = student?.reportCards?.[0]
    if (existingReport) {
      setReportForm({
        studentId,
        discipline: existingReport.discipline,
        cleanliness: existingReport.cleanliness,
        classWorkPresentation: existingReport.classWorkPresentation,
        adherenceToSchool: existingReport.adherenceToSchool,
        coCurricularActivities: existingReport.coCurricularActivities,
        considerationToOthers: existingReport.considerationToOthers,
        speakingEnglish: existingReport.speakingEnglish,
        classTeacherComment: existingReport.classTeacherComment || "",
      })
    } else {
      setReportForm({ ...reportForm, studentId })
    }
  }

  const updateBulkReport = (studentId: string, field: string, value: string) => {
    setBulkReports((prev) =>
      prev.map((report) => (report.studentId === studentId ? { ...report, [field]: value } : report)),
    )
  }

  const getFilteredStudents = () => {
    let filtered = students.filter((student) => student.name.toLowerCase().includes(searchTerm.toLowerCase()))

    // Filter by division
    if (divisionFilter !== "all") {
      filtered = filtered.filter((student) => {
        const division = student.divisions[selectedExamType]
        return division?.division === divisionFilter
      })
    }

    // Filter by report status
    if (reportStatusFilter !== "all") {
      if (reportStatusFilter === "has_report") {
        filtered = filtered.filter((student) => student.reportCards.length > 0)
      } else if (reportStatusFilter === "no_report") {
        filtered = filtered.filter((student) => student.reportCards.length === 0)
      } else if (reportStatusFilter === "approved") {
        filtered = filtered.filter((student) => student.reportCards.some((report) => report.isApproved))
      } else if (reportStatusFilter === "pending") {
        filtered = filtered.filter((student) => student.reportCards.some((report) => !report.isApproved))
      }
    }

    return filtered
  }

  const filteredStudents = getFilteredStudents()
  const currentStats = statistics[selectedExamType] || {
    totalStudents: 0,
    divisions: {},
    passRate: 0,
  }

  const getDivisionProgress = (division: string) => {
    const count = currentStats.divisions[division] || 0
    const percentage = currentStats.totalStudents > 0 ? (count / currentStats.totalStudents) * 100 : 0
    return Math.round(percentage)
  }

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Advanced Student Performance & Reports</h1>
          <p className="text-gray-600 mt-2">Division-based academic performance and behavioral assessments</p>
          {gradingSystem && <p className="text-sm text-gray-500 mt-1">Using grading system: {gradingSystem.name}</p>}
        </div>
        <div className="flex gap-2">
          <Button
            onClick={fetchStudentsWithDivisions}
            variant="outline"
            size="sm"
            disabled={isRefreshing}
            className="bg-white"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Button onClick={() => setIsAnalyticsDialogOpen(true)} variant="outline" className="bg-white">
            <BarChart3 className="w-4 h-4 mr-2" />
            Analytics
          </Button>
          <Button onClick={handleExportData} variant="outline" disabled={isExporting} className="bg-white">
            <Download className={`w-4 h-4 mr-2 ${isExporting ? "animate-spin" : ""}`} />
            Export
          </Button>
          <Button onClick={() => handleOpenCreateDialog("individual")} className="bg-green-600 hover:bg-green-700">
            <Plus className="w-4 h-4 mr-2" />
            Individual Report
          </Button>
          <Button onClick={() => handleOpenCreateDialog("bulk")} variant="outline">
            <Users className="w-4 h-4 mr-2" />
            Bulk Create/Update
          </Button>
        </div>
      </div>

      {/* Division Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white shadow-xl border-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Trophy className="w-4 h-4 mr-2" />
              Division I
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentStats.divisions.DIVISION_1 || 0}</div>
            <div className="text-xs opacity-80">Aggregate: 4-12</div>
            <Progress value={getDivisionProgress("DIVISION_1")} className="mt-2 bg-green-400" />
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-xl border-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Award className="w-4 h-4 mr-2" />
              Division II
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentStats.divisions.DIVISION_2 || 0}</div>
            <div className="text-xs opacity-80">Aggregate: 13-24</div>
            <Progress value={getDivisionProgress("DIVISION_2")} className="mt-2 bg-blue-400" />
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white shadow-xl border-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Target className="w-4 h-4 mr-2" />
              Division III
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentStats.divisions.DIVISION_3 || 0}</div>
            <div className="text-xs opacity-80">Aggregate: 25-32</div>
            <Progress value={getDivisionProgress("DIVISION_3")} className="mt-2 bg-yellow-400" />
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white shadow-xl border-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <BookOpen className="w-4 h-4 mr-2" />
              Division IV
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentStats.divisions.DIVISION_4 || 0}</div>
            <div className="text-xs opacity-80">Aggregate: 33-35</div>
            <Progress value={getDivisionProgress("DIVISION_4")} className="mt-2 bg-orange-400" />
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white shadow-xl border-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Clock className="w-4 h-4 mr-2" />
              Ungraded
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentStats.divisions.UNGRADED || 0}</div>
            <div className="text-xs opacity-80">Aggregate: 36</div>
            <Progress value={getDivisionProgress("UNGRADED")} className="mt-2 bg-purple-400" />
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white shadow-xl border-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <TrendingUp className="w-4 h-4 mr-2" />
              Pass Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentStats.passRate}%</div>
            <div className="text-xs opacity-80">Overall Success</div>
            <Progress value={currentStats.passRate} className="mt-2 bg-red-400" />
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="bg-white shadow-lg border-0">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filters & Search
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-7 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger>
                <SelectValue placeholder="Select class" />
              </SelectTrigger>
              <SelectContent>
                {classes.map((cls) => (
                  <SelectItem key={cls.id} value={cls.id}>
                    {cls.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedTerm} onValueChange={setSelectedTerm}>
              <SelectTrigger>
                <SelectValue placeholder="Select term" />
              </SelectTrigger>
              <SelectContent>
                {terms.map((term) => (
                  <SelectItem key={term.id} value={term.id}>
                    {term.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedAcademicYear} onValueChange={setSelectedAcademicYear}>
              <SelectTrigger>
                <SelectValue placeholder="Select academic year" />
              </SelectTrigger>
              <SelectContent>
                {academicYears.map((year) => (
                  <SelectItem key={year.id} value={year.id}>
                    {year.name} {year.isCurrent && "(Current)"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={selectedExamType}
              onValueChange={(value) => setSelectedExamType(value as "BOT" | "MID" | "END")}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select exam type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="BOT">Beginning of Term (BOT)</SelectItem>
                <SelectItem value="MID">Mid Term (MID)</SelectItem>
                <SelectItem value="END">End of Term (END)</SelectItem>
              </SelectContent>
            </Select>
            <Select value={divisionFilter} onValueChange={setDivisionFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by division" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Divisions</SelectItem>
                <SelectItem value="DIVISION_1">Division I</SelectItem>
                <SelectItem value="DIVISION_2">Division II</SelectItem>
                <SelectItem value="DIVISION_3">Division III</SelectItem>
                <SelectItem value="DIVISION_4">Division IV</SelectItem>
                <SelectItem value="UNGRADED">Ungraded</SelectItem>
                <SelectItem value="FAIL">Failed</SelectItem>
              </SelectContent>
            </Select>
            <Select value={reportStatusFilter} onValueChange={setReportStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by report status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Reports</SelectItem>
                <SelectItem value="has_report">Has Report</SelectItem>
                <SelectItem value="no_report">No Report</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Students Table with Divisions */}
      <Card className="bg-white shadow-lg border-0">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>
                Student Performance - {terms.find((t) => t.id === selectedTerm)?.name} ({selectedExamType})
              </CardTitle>
              <CardDescription>
                Division-based performance using top 4 subjects. Showing {filteredStudents.length} of {students.length}{" "}
                students.
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-blue-50">
                <GraduationCap className="w-3 h-3 mr-1" />
                {currentStats.totalStudents} Students
              </Badge>
              <Badge variant="outline" className="bg-green-50">
                <Star className="w-3 h-3 mr-1" />
                {currentStats.passRate}% Pass Rate
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead>BOT Division</TableHead>
                  <TableHead>MID Division</TableHead>
                  <TableHead>END Division</TableHead>
                  <TableHead>Report Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.map((student) => {
                  const currentReport = student.reportCards?.[0]
                  return (
                    <TableRow key={student.id} className="hover:bg-gray-50">
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={student.photo || "/placeholder.svg"} alt={student.name} />
                            <AvatarFallback>
                              {student.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")
                                .toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <span className="font-medium">{student.name}</span>
                            <div className="text-xs text-gray-500">{student.gender}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{student.class.name}</Badge>
                      </TableCell>
                      <TableCell>
                        {student.divisions.BOT ? (
                          <div className="space-y-1">
                            <Badge className={getDivisionColor(student.divisions.BOT.division)}>
                              {student.divisions.BOT.label}
                            </Badge>
                            <div className="text-xs text-gray-500">Agg: {student.divisions.BOT.aggregate}</div>
                          </div>
                        ) : (
                          <div className="flex items-center text-gray-400 text-sm">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            No data
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        {student.divisions.MID ? (
                          <div className="space-y-1">
                            <Badge className={getDivisionColor(student.divisions.MID.division)}>
                              {student.divisions.MID.label}
                            </Badge>
                            <div className="text-xs text-gray-500">Agg: {student.divisions.MID.aggregate}</div>
                          </div>
                        ) : (
                          <div className="flex items-center text-gray-400 text-sm">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            No data
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        {student.divisions.END ? (
                          <div className="space-y-1">
                            <Badge className={getDivisionColor(student.divisions.END.division)}>
                              {student.divisions.END.label}
                            </Badge>
                            <div className="text-xs text-gray-500">Agg: {student.divisions.END.aggregate}</div>
                          </div>
                        ) : (
                          <div className="flex items-center text-gray-400 text-sm">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            No data
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        {currentReport ? (
                          <div className="space-y-1">
                            <Badge className="bg-green-100 text-green-800">
                              <FileText className="w-3 h-3 mr-1" />
                              Report Created
                            </Badge>
                            <Badge
                              className={
                                currentReport.isApproved
                                  ? "bg-green-100 text-green-800"
                                  : "bg-orange-100 text-orange-800"
                              }
                            >
                              {currentReport.isApproved ? "Approved" : "Pending"}
                            </Badge>
                          </div>
                        ) : (
                          <Badge variant="outline" className="text-gray-600">
                            No Report
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedStudent(student)
                              setIsViewDialogOpen(true)
                            }}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              handleStudentSelect(student.id)
                              setCreateMode("individual")
                              setIsCreateDialogOpen(true)
                            }}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Analytics Dialog */}
      <Dialog open={isAnalyticsDialogOpen} onOpenChange={setIsAnalyticsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Class Performance Analytics
            </DialogTitle>
            <DialogDescription>Comprehensive analysis of student performance across all exam types</DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Overall Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {["BOT", "MID", "END"].map((examType) => {
                const stats = statistics[examType] || { totalStudents: 0, divisions: {}, passRate: 0 }
                return (
                  <Card key={examType} className="border-2">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg">{examType} Performance</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Total Students</span>
                        <Badge variant="outline">{stats.totalStudents}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Pass Rate</span>
                        <Badge className="bg-green-100 text-green-800">{stats.passRate}%</Badge>
                      </div>
                      <Separator />
                      <div className="space-y-2">
                        {Object.entries(stats.divisions).map(([division, count]) => (
                          <div key={division} className="flex justify-between items-center">
                            <span className="text-xs text-gray-600">{division.replace("DIVISION_", "Div ")}</span>
                            <div className="flex items-center gap-2">
                              <Progress
                                value={stats.totalStudents > 0 ? ((count as number) / stats.totalStudents) * 100 : 0}
                                className="w-16 h-2"
                              />
                              <span className="text-xs font-medium w-6">{count}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Performance Trends */}
            <Card>
              <CardHeader>
                <CardTitle>Performance Trends</CardTitle>
                <CardDescription>Student performance comparison across exam types</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {students.slice(0, 10).map((student) => (
                    <div key={student.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={student.photo || "/placeholder.svg"} />
                          <AvatarFallback className="text-xs">
                            {student.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <span className="font-medium text-sm">{student.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {["BOT", "MID", "END"].map((examType) => {
                          const division = student.divisions[examType as keyof typeof student.divisions]
                          return (
                            <Badge
                              key={examType}
                              className={division ? getDivisionColor(division.division) : "bg-gray-100 text-gray-400"}
                              variant="outline"
                            >
                              {examType}: {division ? division.label : "N/A"}
                            </Badge>
                          )
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>

      {/* Create/Edit Report Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {createMode === "individual" ? "Create/Edit Individual Report" : "Bulk Create/Update Reports"}
            </DialogTitle>
            <DialogDescription>
              {createMode === "individual"
                ? "Create or update a behavioral assessment report for a single student"
                : "Create or update behavioral assessment reports for multiple students at once"}
            </DialogDescription>
          </DialogHeader>

          <Tabs value={createMode} onValueChange={(value) => setCreateMode(value as "individual" | "bulk")}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="individual">Individual Student</TabsTrigger>
              <TabsTrigger value="bulk">Bulk Class Creation</TabsTrigger>
            </TabsList>

            <TabsContent value="individual" className="space-y-4">
              <form onSubmit={handleCreateReport} className="space-y-4">
                <div>
                  <Label htmlFor="student">Select Student</Label>
                  <Select value={reportForm.studentId} onValueChange={handleStudentSelect}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a student" />
                    </SelectTrigger>
                    <SelectContent>
                      {students.map((student) => (
                        <SelectItem key={student.id} value={student.id}>
                          {student.name} - {student.class.name}
                          {student.reportCards.length > 0 && " (Has Report)"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Show individual student divisions if selected */}
                {selectedStudent && (
                  <div className="mb-6 p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium mb-3 flex items-center">
                      <Trophy className="w-4 h-4 mr-2" />
                      {selectedStudent.name}'s Academic Performance (Divisions)
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {["BOT", "MID", "END"].map((examType) => {
                        const division = selectedStudent.divisions[examType as keyof typeof selectedStudent.divisions]
                        return (
                          <div key={examType} className="bg-white p-4 rounded border">
                            <div className="flex items-center justify-between mb-3">
                              <span className="font-medium text-sm">{examType}</span>
                              {division ? (
                                <Badge className={getDivisionColor(division.division)}>{division.label}</Badge>
                              ) : (
                                <Badge variant="outline">No Data</Badge>
                              )}
                            </div>
                            {division && (
                              <div className="space-y-2">
                                <div className="text-sm font-medium">Aggregate: {division.aggregate}</div>
                                <div className="space-y-1">
                                  <div className="text-xs font-medium text-gray-600">Top 4 Subjects:</div>
                                  {division.subjects.map((subject) => (
                                    <div key={subject.subjectId} className="flex justify-between text-xs">
                                      <span>{subject.subjectName}</span>
                                      <span className="font-medium">
                                        {subject.grade} ({subject.gradeValue})
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}

                {/* Behavioral Assessment Form */}
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { key: "discipline", label: "Discipline" },
                    { key: "cleanliness", label: "Cleanliness" },
                    { key: "classWorkPresentation", label: "Class Work Presentation" },
                    { key: "adherenceToSchool", label: "Adherence to School Rules" },
                    { key: "coCurricularActivities", label: "Co-Curricular Activities" },
                    { key: "considerationToOthers", label: "Consideration to Others" },
                    { key: "speakingEnglish", label: "Speaking English" },
                  ].map((field) => (
                    <div key={field.key} className="space-y-2">
                      <Label htmlFor={field.key}>{field.label}</Label>
                      <Select
                        value={reportForm[field.key as keyof typeof reportForm]}
                        onValueChange={(value) => setReportForm({ ...reportForm, [field.key]: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
                        </SelectTrigger>
                        <SelectContent>
                          {getGradeOptions().map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  ))}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="classTeacherComment">Class Teacher Comment</Label>
                  <Textarea
                    id="classTeacherComment"
                    placeholder="Enter your comment about the student's behavior and performance..."
                    value={reportForm.classTeacherComment}
                    onChange={(e) => setReportForm({ ...reportForm, classTeacherComment: e.target.value })}
                    rows={3}
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={!reportForm.studentId || isSubmitting}>
                    <Send className="h-4 w-4 mr-2" />
                    {isSubmitting ? "Saving..." : "Save Report"}
                  </Button>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="bulk" className="space-y-4">
              {students.length > 0 && (
                <div className="space-y-6">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-green-900 mb-2">Bulk Report Management</h3>
                    <p className="text-green-700 text-sm">
                      Create new reports or update existing ones for all students in the class. Academic performance
                      shows division-based results.
                    </p>
                    {gradingSystem && <p className="text-green-600 text-xs mt-1">Using: {gradingSystem.name}</p>}
                  </div>

                  <ScrollArea className="max-h-96">
                    <div className="space-y-4">
                      {students.map((student, index) => {
                        const bulkReport = bulkReports[index]
                        return (
                          <Card
                            key={student.id}
                            className={`border-2 ${bulkReport?.hasExistingReport ? "border-blue-200 bg-blue-50" : "border-gray-200"}`}
                          >
                            <CardHeader className="pb-3">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <Avatar className="h-8 w-8">
                                    <AvatarImage src={student.photo || "/placeholder.svg"} />
                                    <AvatarFallback>
                                      {student.name
                                        .split(" ")
                                        .map((n) => n[0])
                                        .join("")}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <CardTitle className="text-base">{student.name}</CardTitle>
                                    <CardDescription className="flex items-center gap-2">
                                      {student.class.name}
                                      {bulkReport?.hasExistingReport && (
                                        <Badge variant="outline" className="text-xs">
                                          <Edit className="w-3 h-3 mr-1" />
                                          Editing Existing
                                        </Badge>
                                      )}
                                    </CardDescription>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  {student.divisions[selectedExamType] && (
                                    <Badge className={getDivisionColor(student.divisions[selectedExamType]!.division)}>
                                      {student.divisions[selectedExamType]!.label}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </CardHeader>
                            <CardContent className="space-y-3">
                              {/* Division Performance Display */}
                              <div className="grid grid-cols-3 gap-2 p-3 bg-gray-50 rounded-lg">
                                {["BOT", "MID", "END"].map((examType) => {
                                  const division = student.divisions[examType as keyof typeof student.divisions]
                                  return (
                                    <div key={examType} className="text-center">
                                      <div className="text-xs font-medium text-gray-600 mb-1">{examType}</div>
                                      {division ? (
                                        <div className="space-y-1">
                                          <Badge
                                            className={`${getDivisionColor(division.division)} text-xs`}
                                            variant="outline"
                                          >
                                            {division.label}
                                          </Badge>
                                          <div className="text-xs text-gray-500">Agg: {division.aggregate}</div>
                                        </div>
                                      ) : (
                                        <Badge variant="outline" className="text-xs">
                                          No Data
                                        </Badge>
                                      )}
                                    </div>
                                  )
                                })}
                              </div>

                              {/* Behavioral Assessment */}
                              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                {[
                                  { key: "discipline", label: "Discipline" },
                                  { key: "cleanliness", label: "Cleanliness" },
                                  { key: "classWorkPresentation", label: "Class Work" },
                                  { key: "adherenceToSchool", label: "School Rules" },
                                  { key: "coCurricularActivities", label: "Co-Curricular" },
                                  { key: "considerationToOthers", label: "Consideration" },
                                  { key: "speakingEnglish", label: "Speaking English" },
                                ].map((field) => (
                                  <div key={field.key} className="space-y-1">
                                    <Label className="text-xs">{field.label}</Label>
                                    <Select
                                      value={bulkReports[index]?.[field.key] || ""}
                                      onValueChange={(value) => updateBulkReport(student.id, field.key, value)}
                                    >
                                      <SelectTrigger className="h-8">
                                        <SelectValue placeholder="Grade" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {getGradeOptions().map((option) => (
                                          <SelectItem key={option.value} value={option.value}>
                                            {option.value}
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  </div>
                                ))}
                              </div>

                              <div className="space-y-1">
                                <Label className="text-xs">Comment</Label>
                                <Textarea
                                  placeholder="Class teacher comment..."
                                  value={bulkReports[index]?.classTeacherComment || ""}
                                  onChange={(e) => updateBulkReport(student.id, "classTeacherComment", e.target.value)}
                                  rows={2}
                                  className="text-sm"
                                />
                              </div>
                            </CardContent>
                          </Card>
                        )
                      })}
                    </div>
                  </ScrollArea>

                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleBulkCreateReports} disabled={isSubmitting}>
                      <Send className="h-4 w-4 mr-2" />
                      {isSubmitting ? "Processing..." : `Save ${students.length} Reports`}
                    </Button>
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* View Student Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-5xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Comprehensive Student Profile</DialogTitle>
            <DialogDescription>Complete academic performance and behavioral assessment overview</DialogDescription>
          </DialogHeader>

          {selectedStudent && (
            <div className="space-y-6">
              {/* Student Header */}
              <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg">
                <Avatar className="h-20 w-20">
                  <AvatarImage src={selectedStudent.photo || "/placeholder.svg"} />
                  <AvatarFallback className="text-xl">
                    {selectedStudent.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold">{selectedStudent.name}</h3>
                  <div className="flex items-center gap-4 mt-2">
                    <Badge variant="secondary" className="text-sm">
                      {selectedStudent.class.name}
                    </Badge>
                    <Badge variant="outline" className="text-sm">
                      {selectedStudent.gender}
                    </Badge>
                    <Badge variant="outline" className="text-sm">
                      ID: {selectedStudent.id.slice(-6)}
                    </Badge>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-600">Academic Year</div>
                  <div className="font-medium">
                    {academicYears.find((year) => year.id === selectedAcademicYear)?.name}
                  </div>
                </div>
              </div>

              {/* Academic Performance - Divisions */}
              <Card className="border-2 border-blue-200">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Trophy className="w-5 h-5 text-blue-600" />
                    <span>Academic Performance Analysis</span>
                  </CardTitle>
                  <CardDescription>Division-based performance across all exam types</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {["BOT", "MID", "END"].map((examType) => {
                      const division = selectedStudent.divisions[examType as keyof typeof selectedStudent.divisions]
                      return (
                        <div key={examType} className="bg-gray-50 p-4 rounded-lg border">
                          <div className="flex items-center justify-between mb-4">
                            <div>
                              <span className="font-bold text-lg">{examType}</span>
                              <div className="text-xs text-gray-500">
                                {examType === "BOT" && "Beginning of Term"}
                                {examType === "MID" && "Mid Term"}
                                {examType === "END" && "End of Term"}
                              </div>
                            </div>
                            {division ? (
                              <Badge className={getDivisionColor(division.division)} variant="outline">
                                {division.label}
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="bg-gray-100">
                                No Data
                              </Badge>
                            )}
                          </div>
                          {division && (
                            <div className="space-y-3">
                              <div className="flex justify-between items-center p-2 bg-white rounded">
                                <span className="text-sm font-medium">Aggregate Score</span>
                                <Badge className="bg-blue-100 text-blue-800">{division.aggregate}</Badge>
                              </div>
                              <div className="space-y-2">
                                <div className="text-xs font-medium text-gray-600 mb-2">Top 4 Subjects:</div>
                                {division.subjects.map((subject) => (
                                  <div
                                    key={subject.subjectId}
                                    className="flex justify-between items-center p-2 bg-white rounded text-sm"
                                  >
                                    <span className="font-medium">{subject.subjectName}</span>
                                    <div className="flex items-center gap-2">
                                      <Badge variant="outline" className="text-xs">
                                        {subject.grade}
                                      </Badge>
                                      <span className="text-xs text-gray-500">({subject.gradeValue})</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Parent Information */}
              {selectedStudent.parent && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="w-5 h-5" />
                      Parent/Guardian Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center gap-3 p-3 bg-gray-50 rounded">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <Users className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Parent Name</div>
                          <div className="font-medium">{selectedStudent.parent.name}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 bg-gray-50 rounded">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                          <ExternalLink className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Email Address</div>
                          <div className="font-medium">{selectedStudent.parent.email}</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Report Cards History */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Behavioral Assessment Reports ({selectedStudent.reportCards.length})
                  </CardTitle>
                  <CardDescription>Complete history of behavioral assessments and teacher comments</CardDescription>
                </CardHeader>
                <CardContent>
                  {selectedStudent.reportCards.length > 0 ? (
                    <div className="space-y-4">
                      {selectedStudent.reportCards.map((report) => (
                        <div key={report.id} className="border rounded-lg p-4 bg-gray-50">
                          <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                <FileText className="w-4 h-4 text-blue-600" />
                              </div>
                              <div>
                                <span className="font-medium">Report #{report.id.slice(-8)}</span>
                                <div className="text-xs text-gray-500">
                                  Created: {new Date(report.createdAt).toLocaleDateString()}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge
                                className={
                                  report.isApproved ? "bg-green-100 text-green-800" : "bg-orange-100 text-orange-800"
                                }
                              >
                                {report.isApproved ? "Approved" : "Pending Approval"}
                              </Badge>
                              {report.approvedAt && (
                                <div className="text-xs text-gray-500">
                                  Approved: {new Date(report.approvedAt).toLocaleDateString()}
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                            {[
                              { key: "discipline", label: "Discipline", value: report.discipline },
                              { key: "cleanliness", label: "Cleanliness", value: report.cleanliness },
                              {
                                key: "classWorkPresentation",
                                label: "Class Work",
                                value: report.classWorkPresentation,
                              },
                              { key: "adherenceToSchool", label: "School Rules", value: report.adherenceToSchool },
                              {
                                key: "coCurricularActivities",
                                label: "Co-Curricular",
                                value: report.coCurricularActivities,
                              },
                              {
                                key: "considerationToOthers",
                                label: "Consideration",
                                value: report.considerationToOthers,
                              },
                              { key: "speakingEnglish", label: "Speaking English", value: report.speakingEnglish },
                            ].map((field) => (
                              <div key={field.key} className="text-center p-2 bg-white rounded border">
                                <div className="text-xs text-gray-600 mb-1">{field.label}</div>
                                <Badge variant="outline" className="text-sm">
                                  {field.value}
                                </Badge>
                              </div>
                            ))}
                          </div>

                          {report.classTeacherComment && (
                            <div className="bg-white p-3 rounded border">
                              <div className="text-sm font-medium text-gray-700 mb-2">Class Teacher Comment:</div>
                              <p className="text-sm text-gray-600 italic">"{report.classTeacherComment}"</p>
                            </div>
                          )}

                          {report.headteacherComment && (
                            <div className="bg-blue-50 p-3 rounded border border-blue-200 mt-2">
                              <div className="text-sm font-medium text-blue-700 mb-2">Head Teacher Comment:</div>
                              <p className="text-sm text-blue-600 italic">"{report.headteacherComment}"</p>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-500 text-lg">No behavioral assessment reports found</p>
                      <p className="text-gray-400 text-sm">
                        Create a report to track this student's behavioral progress
                      </p>
                      <Button
                        onClick={() => {
                          handleStudentSelect(selectedStudent.id)
                          setCreateMode("individual")
                          setIsViewDialogOpen(false)
                          setIsCreateDialogOpen(true)
                        }}
                        className="mt-4"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Create First Report
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <div className="flex justify-end gap-2 pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                    handleStudentSelect(selectedStudent.id)
                    setCreateMode("individual")
                    setIsViewDialogOpen(false)
                    setIsCreateDialogOpen(true)
                  }}
                >
                  <Edit className="w-4 h-4 mr-2" />
                  {selectedStudent.reportCards.length > 0 ? "Edit Report" : "Create Report"}
                </Button>
                <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
