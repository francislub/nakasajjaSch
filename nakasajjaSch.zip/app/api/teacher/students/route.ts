import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { getGradeFromSystem } from "@/lib/grading"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const classId = searchParams.get("classId")
    const termId = searchParams.get("termId")
    const search = searchParams.get("search")

    // Get classes assigned to this teacher
    const teacherClasses = await prisma.class.findMany({
      where: {
        classTeacherId: session.user.id,
      },
      select: {
        id: true,
      },
    })

    const classIds = teacherClasses.map((cls) => cls.id)

    if (classIds.length === 0) {
      return NextResponse.json({ students: [] })
    }

    // Get the most recent grading system (since there's no isActive field)
    const gradingSystem = await prisma.gradingSystem.findFirst({
      orderBy: { createdAt: "desc" },
    })

    // Build where clause
    const whereClause: any = {
      classId: classId && classIds.includes(classId) ? classId : { in: classIds },
    }

    if (search) {
      whereClause.name = {
        contains: search,
        mode: "insensitive",
      }
    }

    // Get students with their marks and report cards
    const students = await prisma.student.findMany({
      where: whereClause,
      include: {
        class: {
          select: {
            id: true,
            name: true,
          },
        },
        parent: {
          select: {
            name: true,
            email: true,
          },
        },
        marks: {
          where: termId && termId !== "all" ? { termId } : {},
          include: {
            subject: {
              select: {
                id: true,
                name: true,
                code: true,
              },
            },
          },
          orderBy: [
            {
              subject: {
                name: "asc",
              },
            },
            {
              createdAt: "asc",
            },
          ],
        },
        reportCards: {
          select: {
            id: true,
            createdAt: true,
            updatedAt: true,
            discipline: true,
            cleanliness: true,
            classWorkPresentation: true,
            adherenceToSchool: true,
            coCurricularActivities: true,
            considerationToOthers: true,
            speakingEnglish: true,
            classTeacherComment: true,
            headteacherComment: true,
          },
          orderBy: {
            createdAt: "desc",
          },
        },
        attendance: {
          select: {
            status: true,
            date: true,
          },
        },
      },
      orderBy: {
        name: "asc",
      },
    })

    // Process students to include subject performance summary
    const studentsWithPerformance = students.map((student) => {
      // Group marks by subject
      const subjectMarks = student.marks.reduce((acc: any, mark) => {
        const subjectId = mark.subject.id
        if (!acc[subjectId]) {
          acc[subjectId] = {
            subject: mark.subject,
            marks: [],
            botMarks: [],
            midMarks: [],
            endMarks: [],
          }
        }

        acc[subjectId].marks.push(mark)

        // Group by exam type if available
        if (mark.examType === "BOT") {
          acc[subjectId].botMarks.push(mark)
        } else if (mark.examType === "MID") {
          acc[subjectId].midMarks.push(mark)
        } else if (mark.examType === "END") {
          acc[subjectId].endMarks.push(mark)
        }

        return acc
      }, {})

      // Calculate averages for each subject
      const subjectPerformance = Object.values(subjectMarks).map((subjectData: any) => {
        const botAvg =
          subjectData.botMarks.length > 0
            ? subjectData.botMarks.reduce((sum: number, mark: any) => sum + (mark.score || 0), 0) /
              subjectData.botMarks.length
            : 0

        const midAvg =
          subjectData.midMarks.length > 0
            ? subjectData.midMarks.reduce((sum: number, mark: any) => sum + (mark.score || 0), 0) /
              subjectData.midMarks.length
            : 0

        const endAvg =
          subjectData.endMarks.length > 0
            ? subjectData.endMarks.reduce((sum: number, mark: any) => sum + (mark.score || 0), 0) /
              subjectData.endMarks.length
            : 0

        // Calculate total average from all marks if no exam type separation
        const allMarksAvg =
          subjectData.marks.length > 0
            ? subjectData.marks.reduce((sum: number, mark: any) => sum + (mark.score || 0), 0) /
              subjectData.marks.length
            : 0

        const totalAvg = botAvg + midAvg + endAvg > 0 ? (botAvg + midAvg + endAvg) / 3 : allMarksAvg

        return {
          subject: subjectData.subject,
          botAverage: Math.round(botAvg * 10) / 10,
          midAverage: Math.round(midAvg * 10) / 10,
          endAverage: Math.round(endAvg * 10) / 10,
          totalAverage: Math.round(totalAvg * 10) / 10,
          grade: getGradeFromSystem(totalAvg, gradingSystem),
          botMarks: subjectData.botMarks,
          midMarks: subjectData.midMarks,
          endMarks: subjectData.endMarks,
          allMarks: subjectData.marks,
        }
      })

      // Calculate overall average
      const overallAverage =
        subjectPerformance.length > 0
          ? subjectPerformance.reduce((sum, subject) => sum + subject.totalAverage, 0) / subjectPerformance.length
          : 0

      return {
        ...student,
        subjectPerformance,
        overallAverage: Math.round(overallAverage * 10) / 10,
        overallGrade: getGradeFromSystem(overallAverage, gradingSystem),
      }
    })

    return NextResponse.json({
      students: studentsWithPerformance,
      gradingSystem,
    })
  } catch (error) {
    console.error("Error fetching teacher students:", error)
    return NextResponse.json({ error: "Failed to fetch students" }, { status: 500 })
  }
}
