// Utility function for consistent grading across the application
export function getGradeFromSystem(score: number, gradingSystem: any): string {
    if (!gradingSystem) {
      // Fallback grading if no system found
      if (score >= 80) return "A"
      if (score >= 70) return "B"
      if (score >= 60) return "C"
      if (score >= 50) return "D"
      return "F"
    }
  
    // Handle different grading system structures
    // If it's the old structure with individual grade records
    if (gradingSystem.grade && gradingSystem.minMark !== undefined) {
      // This is a single grade record, we need to get all grades
      // For now, use fallback logic
      if (score >= 80) return "A"
      if (score >= 70) return "B"
      if (score >= 60) return "C"
      if (score >= 50) return "D"
      return "F"
    }
  
    // If it has a grades array (new structure)
    if (gradingSystem.grades) {
      const grades = typeof gradingSystem.grades === "string" ? JSON.parse(gradingSystem.grades) : gradingSystem.grades
  
      // Sort grades by minScore in descending order
      const sortedGrades = grades.sort(
        (a: any, b: any) => (b.minScore || b.minMark || 0) - (a.minScore || a.minMark || 0),
      )
  
      // Find the appropriate grade
      for (const grade of sortedGrades) {
        const minScore = grade.minScore || grade.minMark || 0
        if (score >= minScore) {
          return grade.grade
        }
      }
  
      // Return the lowest grade if no match found
      return sortedGrades[sortedGrades.length - 1]?.grade || "F"
    }
  
    // Fallback grading
    if (score >= 80) return "A"
    if (score >= 70) return "B"
    if (score >= 60) return "C"
    if (score >= 50) return "D"
    return "F"
  }
  
  // Get grade color for UI display
  export function getGradeColor(grade: string): string {
    switch (grade.toUpperCase()) {
      case "A":
        return "bg-green-100 text-green-800 border-green-200"
      case "B":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "C":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "D":
        return "bg-orange-100 text-orange-800 border-orange-200"
      case "F":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }
  
  // Calculate grade from percentage score
  export function calculateGrade(score: number, gradingSystem?: any): string {
    return getGradeFromSystem(score, gradingSystem)
  }
  
  // Get all available grades from grading system
  export function getAvailableGrades(gradingSystem: any): Array<{ value: string; label: string; minScore: number }> {
    if (!gradingSystem) {
      return [
        { value: "A", label: "A - Excellent", minScore: 80 },
        { value: "B", label: "B - Good", minScore: 70 },
        { value: "C", label: "C - Fair", minScore: 60 },
        { value: "D", label: "D - Pass", minScore: 50 },
        { value: "F", label: "F - Fail", minScore: 0 },
      ]
    }
  
    // Handle single grade record structure
    if (gradingSystem.grade && gradingSystem.minMark !== undefined) {
      return [
        { value: "A", label: "A - Excellent", minScore: 80 },
        { value: "B", label: "B - Good", minScore: 70 },
        { value: "C", label: "C - Fair", minScore: 60 },
        { value: "D", label: "D - Pass", minScore: 50 },
        { value: "F", label: "F - Fail", minScore: 0 },
      ]
    }
  
    // Handle grades array structure
    if (gradingSystem.grades) {
      const grades = typeof gradingSystem.grades === "string" ? JSON.parse(gradingSystem.grades) : gradingSystem.grades
  
      return grades
        .map((grade: any) => ({
          value: grade.grade,
          label: `${grade.grade} - ${grade.description || grade.label || grade.comment || grade.grade}`,
          minScore: grade.minScore || grade.minMark || 0,
        }))
        .sort((a: any, b: any) => b.minScore - a.minScore)
    }
  
    // Fallback
    return [
      { value: "A", label: "A - Excellent", minScore: 80 },
      { value: "B", label: "B - Good", minScore: 70 },
      { value: "C", label: "C - Fair", minScore: 60 },
      { value: "D", label: "D - Pass", minScore: 50 },
      { value: "F", label: "F - Fail", minScore: 0 },
    ]
  }
  
  // Validate if a grade is valid according to the grading system
  export function isValidGrade(grade: string, gradingSystem?: any): boolean {
    const availableGrades = getAvailableGrades(gradingSystem)
    return availableGrades.some((g) => g.value === grade.toUpperCase())
  }
  
  // Get grade description
  export function getGradeDescription(grade: string, gradingSystem?: any): string {
    const availableGrades = getAvailableGrades(gradingSystem)
    const gradeInfo = availableGrades.find((g) => g.value === grade.toUpperCase())
    return gradeInfo?.label || grade
  }
  